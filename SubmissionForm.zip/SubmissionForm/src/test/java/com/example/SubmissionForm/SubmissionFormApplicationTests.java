package com.example.SubmissionForm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubmissionFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
